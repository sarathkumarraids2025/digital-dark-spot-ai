# Digital Dark Spot AI
AI-assisted information gap detection: enter a research question plus sources (URLs, PDF, DOCX, TXT) and get evidence-linked potential gaps, conflicts, outdated-source warnings, unanswered questions, a verification checklist and a PDF report.

## Run on Windows (Python 3.12)
```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000 and press "Run scholarship demo". Tests: `pytest -q`.

## Method (honest)
Rule-based lexical analysis (keyword aspect mapping, regex date/amount/document extraction, cross-source comparison). No neural model, no training, no accuracy claims. Coverage = aspects with at least one supporting statement / aspects checked. Findings are potential signals.

## Pages
Dashboard, New Research, History, Source Library, Gap Intelligence, Conflict Radar, Freshness Monitor, Unanswered Questions, Knowledge Graph (Cytoscape), Verification Center, Reports (PDF), Settings (theme + English/Tamil), About.

## Known limitations
Charts and the graph load Chart.js/Cytoscape from a CDN, so they need internet. Tamil covers the sidebar, page titles and main buttons only; PDFs are English. No landing page. Aspects are tuned for scholarship-style topics. Task statuses are Pending / In Progress / Completed.
**Commit the `templates/` and `tests/` folders to GitHub too; the app cannot run without `templates/`.**

## Deploy
`Procfile` provided (gunicorn). Set SECRET_KEY. SQLite on free hosts may reset; use DATABASE_URL for persistence.
