"""Evidence-first information-gap analysis. Method: rule-based keyword aspect matching,
regex date/number extraction and set comparison. No neural model is used or claimed."""
import re, io, socket, ipaddress, urllib.parse, urllib.robotparser, datetime as dt
import requests

METHOD = ("Rule-based lexical analysis: sentences are mapped to research aspects by keyword matching; "
          "dates, amounts and document names are extracted with regular expressions and compared across "
          "different sources. No deep-learning or embedding model is used. All findings are potential signals, "
          "not verified facts.")

ASPECTS = {  # name: (keywords, severity if missing, why it matters)
 "Eligibility conditions": (["eligib","qualif","criteria","must be","open to"], "High", "Applying without confirming eligibility can waste effort or cause rejection."),
 "Application deadline": (["deadline","last date","closes","apply by","due date","due on"], "Critical", "A missed or wrong deadline can end the application."),
 "Required documents": (["document","certificate","marksheet","passbook","salary slip","aadhaar","transcript"], "High", "Missing paperwork is a common reason for rejection."),
 "Income / financial criteria": (["family income","annual income","per annum","income limit","income below","income of"], "Medium", "Financial limits decide who qualifies."),
 "Renewal conditions": (["renew","continuation","re-apply","maintain a","retain"], "High", "Benefits may stop after year one if renewal rules are unknown."),
 "Application process / link": (["apply online","portal","application form","how to apply","application link"], "Medium", "Users need the official route to apply."),
 "Award amount / benefits": (["stipend","award amount","amount of","tuition","scholarship amount","benefit"], "Medium", "The benefit size affects the decision."),
 "Contact / official notice": (["contact","helpdesk","official notice","notification","email us"], "Low", "Lets the user confirm details with the issuer."),
}
MON = r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?"
DATE_RE = re.compile(rf"\b\d{{1,2}}(?:st|nd|rd|th)?\s+{MON},?\s+\d{{4}}\b|\b{MON}\s+\d{{1,2}}(?:st|nd|rd|th)?,?\s+\d{{4}}\b", re.I)
MONEY_RE = re.compile(r"(?:₹|rs\.?|inr|\$)\s?\d[\d,]*(?:\.\d+)?", re.I)
DOC_TERMS = ["income certificate","salary slip","tax return","aadhaar","marksheet","transcript","passport photo","bank passbook","bonafide certificate","community certificate","ration card"]

def dates(t): return {re.sub(r"[,.]", "", d.lower()) for d in DATE_RE.findall(t)}
def money(t): return {re.sub(r"[\s,]", "", m.lower()) for m in MONEY_RE.findall(t)}
def docs(t): return {d for d in DOC_TERMS if d in t.lower()}

def sentences(text):
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n+", text) if 25 <= len(s.strip()) <= 400]

def aspect_of(s):
    low, best, n = s.lower(), None, 0
    for a, (kw, _, _) in ASPECTS.items():
        h = sum(k in low for k in kw)
        if h > n: best, n = a, h
    return best

def freshness(txt, cy):
    ys = [int(y) for y in re.findall(r"\b(20[0-4]\d)\b", txt)]
    if not ys: return "Undated", "No year or date was found in the text.", None
    m = max(ys)
    u = re.search(r"(last updated|updated on|published|last modified)[^.\n]{0,40}", txt, re.I)
    ev = f' (text says: "{u.group(0).strip()}")' if u else ""
    if m < cy: return "Potentially Outdated", f"Latest year mentioned is {m}, earlier than {cy}{ev}. It may describe an older cycle; old does not automatically mean wrong.", m
    return "Current", f"Mentions {m}{ev}. A recent year is not proof that the page is current.", m

# ---------- source reading ----------
def valid_url(u):
    p = urllib.parse.urlparse(u)
    return p.scheme in ("http", "https") and bool(p.netloc) and "." in p.netloc

def _safe_host(host):
    for info in socket.getaddrinfo(host, None):
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved: return False
    return True

def fetch_url(u):
    """Returns (status, text, note). Blocks private hosts (SSRF), honours robots.txt, 8s timeout, 1MB cap."""
    try:
        p = urllib.parse.urlparse(u)
        if not _safe_host(p.hostname): return "Failed", "", "Blocked: address is private/internal."
        rp = urllib.robotparser.RobotFileParser(f"{p.scheme}://{p.netloc}/robots.txt")
        try:
            r = requests.get(rp.url, timeout=5)
            rp.parse(r.text.splitlines() if r.status_code == 200 else [])
        except Exception: rp.parse([])
        if not rp.can_fetch("DigitalDarkSpotBot", u): return "Failed", "", "Blocked by robots.txt; not analysed."
        r = requests.get(u, timeout=8, headers={"User-Agent": "DigitalDarkSpotBot/1.0"}, stream=True)
        if r.status_code != 200: return "Failed", "", f"HTTP {r.status_code}; not analysed."
        raw = r.raw.read(1_000_000, decode_content=True).decode(r.encoding or "utf-8", "ignore")
        txt = re.sub(r"<(script|style)[\s\S]*?</\1>", " ", raw, flags=re.I)
        txt = re.sub(r"</(p|div|li|tr|h\d|br)>", ".\n", txt, flags=re.I)
        txt = re.sub(r"<[^>]+>", " ", txt); txt = re.sub(r"[ \t]+", " ", txt)
        return ("Analysed", txt, "") if len(txt.strip()) > 50 else ("Failed", "", "Page had no readable text (may need JavaScript).")
    except Exception as e:
        return "Failed", "", f"Could not fetch: {type(e).__name__}"

def read_file(name, data):
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    if ext not in ("pdf", "docx", "txt"): raise ValueError("Only PDF, DOCX and TXT files are allowed.")
    if not data: raise ValueError("File is empty.")
    if ext == "txt": txt = data.decode("utf-8", "ignore")
    elif ext == "pdf":
        if not data.startswith(b"%PDF"): raise ValueError("File is not a valid PDF.")
        from pypdf import PdfReader
        txt = "\n".join((pg.extract_text() or "") for pg in PdfReader(io.BytesIO(data)).pages)
    else:
        if not data.startswith(b"PK"): raise ValueError("File is not a valid DOCX.")
        import docx
        txt = "\n".join(p.text for p in docx.Document(io.BytesIO(data)).paragraphs)
    if len(txt.strip()) < 30: raise ValueError("No readable text found in the file.")
    return txt

# ---------- analysis ----------
def analyse(question, srcs):
    cy = dt.date.today().year
    sources, claims = [], []
    for s in srcs:
        o = dict(name=s["name"], kind=s["kind"], status=s["status"], note=s.get("note", ""), freshness="Unable to Verify",
                 fresh_reason=s.get("note") or "Source could not be read, so freshness is unknown.", year=None)
        if s["status"] == "Analysed":
            f, r, y = freshness(s["text"], cy); o.update(freshness=f, fresh_reason=r, year=y)
            for sent in sentences(s["text"]):
                a = aspect_of(sent)
                if a: claims.append(dict(source=s["name"], aspect=a, text=sent))
        sources.append(o)
    fresh = {o["name"]: o["freshness"] for o in sources}
    by = {}
    for c in claims: by.setdefault(c["aspect"], set()).add(c["source"])
    gaps, found = [], 0
    for a, (_, sev, why) in ASPECTS.items():
        if a not in by:
            gaps.append(dict(kind="Missing information", title=f"{a} not found", severity=sev, source_ref="None of the sources reviewed",
                strength="No supporting statement found", why=why,
                action=f"Check the latest official source for: {a.lower()}."))
        else:
            found += 1
            if len(by[a]) == 1:
                gaps.append(dict(kind="Unsupported claim", title=f"{a}: single source only", severity="Low", source_ref=next(iter(by[a])),
                    strength="One source only; not cross-checked", why="A claim from one source has not been corroborated.",
                    action=f"Confirm {a.lower()} against a second, official source."))
    confl = []
    seen = set()
    rules = [("Date difference", dates, {"Application deadline"}), ("Amount / number difference", money, {"Income / financial criteria", "Award amount / benefits"}),
             ("Document requirement difference", docs, {"Required documents"})]
    for i, a in enumerate(claims):
        for b in claims[i + 1:]:
            if a["aspect"] != b["aspect"] or a["source"] == b["source"]: continue
            for ct, fn, asp in rules:
                if a["aspect"] not in asp: continue
                va, vb = fn(a["text"]), fn(b["text"])
                k = (ct, a["aspect"], a["source"], b["source"])
                if va and vb and va != vb and k not in seen:
                    seen.add(k)
                    old = "Potentially Outdated" in (fresh[a["source"]], fresh[b["source"]])
                    confl.append(dict(aspect=a["aspect"], ctype=ct + (" (possible different cycle)" if old else ""),
                        a_text=a["text"], a_src=a["source"], b_text=b["text"], b_src=b["source"],
                        severity="Low" if old else ("High" if ct != "Amount / number difference" else "Medium"),
                        confidence="Low" if old else "Medium",
                        resolution="One source looks older, so the difference may reflect an earlier cycle. Confirm with the official notice." if old
                                   else "Compare both passages with the latest official notice; scope or cycle may differ."))
    qs, tasks = [], []
    for g in gaps:
        if g["kind"] == "Missing information":
            qs.append(dict(text=f"What do the official sources say about: {g['title'].replace(' not found','').lower()}?",
                why=f"{g['why']} Needed to answer: \"{question[:90]}\"", priority=g["severity"], source_ref=g["source_ref"]))
        tasks.append(dict(title=g["title"], desc=g["why"], priority=g["severity"], ref=g["source_ref"], action=g["action"]))
    for c in confl:
        qs.append(dict(text=f"Which {c['aspect'].lower()} is correct: {c['a_src']} or {c['b_src']}?", why="Sources appear to differ.",
                       priority=c["severity"], source_ref=f"{c['a_src']} / {c['b_src']}"))
        tasks.append(dict(title=f"Resolve: {c['ctype']} ({c['aspect']})", desc=f"{c['a_src']} and {c['b_src']} differ.", priority=c["severity"],
                          ref=f"{c['a_src']} / {c['b_src']}", action=c["resolution"]))
    for o in sources:
        if o["freshness"] in ("Potentially Outdated", "Undated", "Unable to Verify"):
            p = "Medium" if o["freshness"] != "Unable to Verify" else "High"
            qs.append(dict(text=f"Is there a current version of \"{o['name']}\"?", why=o["fresh_reason"], priority=p, source_ref=o["name"]))
            tasks.append(dict(title=f"Check freshness: {o['name']}", desc=o["fresh_reason"], priority=p, ref=o["name"],
                              action="Find the current official version or confirm the date."))
    total = len(ASPECTS)
    return dict(sources=sources, claims=claims, gaps=gaps, conflicts=confl, questions=qs, tasks=tasks,
                found=found, total=total, coverage=round(100 * found / total, 1))

DEMO = [
 dict(name="DEMO: Official scholarship notice", kind="Demo", status="Analysed", text="""Eligibility: applicants must be Indian citizens enrolled in the first year of a B.E/B.Tech programme.
The last date to apply is 15 December 2026.
Family income must be below Rs. 6,00,000 per annum.
Required documents: income certificate, marksheet and bank passbook.
Apply online through the scholarship portal. Published 10 October 2026."""),
 dict(name="DEMO: Student blog post", kind="Demo", status="Analysed", text="""The scholarship deadline is 30 November 2026 according to this blog.
Students need a salary slip, aadhaar and marksheet as documents.
Family annual income should be below Rs. 8,00,000 per annum.
The award amount of Rs. 50,000 per year is paid as tuition support. Last updated 5 November 2026."""),
 dict(name="DEMO: Old information page", kind="Demo", status="Analysed", text="""Applications for the 2023 cycle close on 31 August 2023. Last updated 12 June 2023.
Eligibility criteria: students must be in first year of engineering.
Required documents: community certificate and marksheet.
Apply online using the application form."""),
]
