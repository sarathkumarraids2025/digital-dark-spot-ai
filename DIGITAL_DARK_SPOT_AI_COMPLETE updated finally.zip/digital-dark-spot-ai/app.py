import os, io, secrets, datetime as dt
from collections import Counter
from xml.sax.saxutils import escape
from flask import Flask, render_template, request, redirect, url_for, flash, send_file, abort, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
import analysis

app = Flask(__name__)
app.config.update(SECRET_KEY=os.environ.get("SECRET_KEY", "dev-change-me"),
    SQLALCHEMY_DATABASE_URI=os.environ.get("DATABASE_URL", "sqlite:///dds.db"), MAX_CONTENT_LENGTH=10 * 1024 * 1024)
db = SQLAlchemy(app)
STATUS = ["Pending", "In Progress", "Completed"]
SEV = ["Critical", "High", "Medium", "Low"]
FRESH = ["Current", "Potentially Outdated", "Undated", "Unable to Verify"]

TR = {"ta": {"Dashboard": "டாஷ்போர்டு", "New Research": "புதிய ஆய்வு", "Research History": "ஆய்வு வரலாறு", "Source Library": "ஆதார நூலகம்",
 "Gap Intelligence": "இடைவெளி பகுப்பாய்வு", "Conflict Radar": "முரண்பாட்டு ரேடார்", "Freshness Monitor": "புதுமை கண்காணிப்பு",
 "Unanswered Questions": "பதிலளிக்கப்படாத கேள்விகள்", "Knowledge Graph": "அறிவு வரைபடம்", "Verification Center": "சரிபார்ப்பு மையம்",
 "Reports": "அறிக்கைகள்", "Research Workplace": "ஆய்வுப் பணியிடம்", "Gap Analysis": "இடைவெளி பகுப்பாய்வு", "Knowledge Map": "அறிவு வரைபடம்", "Research Reports": "ஆய்வு அறிக்கைகள்", "Settings": "அமைப்புகள்", "About": "பற்றி", "Analyse research": "ஆய்வை பகுப்பாய்வு செய்", "Filter": "வடிகட்டு",
 "Reset": "மீட்டமை", "Open": "திற", "Delete": "நீக்கு", "Download PDF report": "PDF அறிக்கையைப் பதிவிறக்கு", "Save settings": "அமைப்புகளைச் சேமி"}}

def child(n): return db.relationship(n, backref="project", cascade="all, delete-orphan")
class Project(db.Model):
    id = db.Column(db.Integer, primary_key=True); title = db.Column(db.String(200)); question = db.Column(db.Text)
    created = db.Column(db.DateTime, default=dt.datetime.utcnow); coverage = db.Column(db.Float, default=0)
    found = db.Column(db.Integer, default=0); total = db.Column(db.Integer, default=0); is_demo = db.Column(db.Boolean, default=False)
    sources = child("Source"); claims = child("Claim"); gaps = child("Gap"); conflicts = child("Conflict"); questions = child("Question"); tasks = child("Task")
class Source(db.Model):
    id = db.Column(db.Integer, primary_key=True); project_id = db.Column(db.ForeignKey("project.id"))
    name = db.Column(db.String(300)); kind = db.Column(db.String(20)); status = db.Column(db.String(20)); note = db.Column(db.Text)
    freshness = db.Column(db.String(30)); fresh_reason = db.Column(db.Text); year = db.Column(db.Integer)
class Claim(db.Model):
    id = db.Column(db.Integer, primary_key=True); project_id = db.Column(db.ForeignKey("project.id"))
    source_id = db.Column(db.ForeignKey("source.id")); aspect = db.Column(db.String(60)); text = db.Column(db.Text)
    source = db.relationship("Source")
class Gap(db.Model):
    id = db.Column(db.Integer, primary_key=True); project_id = db.Column(db.ForeignKey("project.id"))
    kind = db.Column(db.String(40)); title = db.Column(db.String(200)); why = db.Column(db.Text); severity = db.Column(db.String(10))
    strength = db.Column(db.String(100)); source_ref = db.Column(db.Text); action = db.Column(db.Text); status = db.Column(db.String(20), default="Pending")
class Conflict(db.Model):
    id = db.Column(db.Integer, primary_key=True); project_id = db.Column(db.ForeignKey("project.id"))
    aspect = db.Column(db.String(60)); ctype = db.Column(db.String(80)); a_text = db.Column(db.Text); a_src = db.Column(db.Text)
    b_text = db.Column(db.Text); b_src = db.Column(db.Text); severity = db.Column(db.String(10)); confidence = db.Column(db.String(10)); resolution = db.Column(db.Text)
class Question(db.Model):
    id = db.Column(db.Integer, primary_key=True); project_id = db.Column(db.ForeignKey("project.id"))
    text = db.Column(db.Text); why = db.Column(db.Text); priority = db.Column(db.String(10)); source_ref = db.Column(db.Text); resolved = db.Column(db.Boolean, default=False)
class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True); project_id = db.Column(db.ForeignKey("project.id"))
    title = db.Column(db.String(300)); desc = db.Column(db.Text); priority = db.Column(db.String(10)); ref = db.Column(db.Text); action = db.Column(db.Text)
    status = db.Column(db.String(20), default="Pending"); created = db.Column(db.DateTime, default=dt.datetime.utcnow)
with app.app_context(): db.create_all()

@app.before_request
def csrf():
    if request.method == "POST" and (not session.get("_t") or request.form.get("_t") != session["_t"]): abort(400)
@app.context_processor
def inject():
    session.setdefault("_t", secrets.token_hex(16))
    return dict(token=session["_t"], SEV=SEV, STATUS=STATUS, FRESH=FRESH, theme=session.get("theme", ""), lang=session.get("lang", "en"),
                t=lambda x: TR.get(session.get("lang"), {}).get(x, x))
@app.errorhandler(400)
@app.errorhandler(404)
@app.errorhandler(413)
@app.errorhandler(500)
def err(e): return render_template("error.html", code=getattr(e, "code", 500)), getattr(e, "code", 500)

def create_project(question, srcs, demo=False):
    r = analysis.analyse(question, srcs)
    p = Project(title=question[:80], question=question, is_demo=demo, coverage=r["coverage"], found=r["found"], total=r["total"])
    db.session.add(p); smap = {}
    for s in r["sources"]:
        o = Source(project=p, **s); db.session.add(o); smap[s["name"]] = o
    db.session.flush()
    for c in r["claims"]: db.session.add(Claim(project=p, source=smap[c["source"]], aspect=c["aspect"], text=c["text"]))
    for k, M in (("gaps", Gap), ("conflicts", Conflict), ("questions", Question), ("tasks", Task)):
        for x in r[k]: db.session.add(M(project=p, **x))
    db.session.commit(); return p

@app.route("/")
def dashboard():
    P = Project.query.order_by(Project.created.desc()).all(); gaps = Gap.query.all()
    d = dict(gapdist=[sum(g.kind == "Missing information" for g in gaps), sum(g.kind == "Unsupported claim" for g in gaps),
                      Conflict.query.count(), Source.query.filter_by(freshness="Potentially Outdated").count()],
             fresh=[Source.query.filter_by(freshness=f).count() for f in FRESH], tasks=[Task.query.filter_by(status=s).count() for s in STATUS],
             cov=[[f"#{p.id}", p.coverage] for p in P], act=sorted(Counter(p.created.strftime("%Y-%m-%d") for p in P).items()))
    k = [("Research projects", len(P), "c1"), ("Sources analysed", Source.query.filter_by(status="Analysed").count(), "c2"), ("Information gaps", len(gaps), "c3"),
         ("Potential conflicts", d["gapdist"][2], "c4"), ("Potentially outdated", d["gapdist"][3], "c5"), ("Pending tasks", d["tasks"][0], "c6")]
    return render_template("dashboard.html", P=P, d=d, kpis=k, title="Dashboard")

def collect():
    f = request.form; q = f.get("question", "").strip(); errs, srcs, urls = [], [], []
    if len(q) < 10: errs.append("Enter a research question of at least 10 characters.")
    for u in f.getlist("url"):
        u = u.strip()
        if not u: continue
        if not analysis.valid_url(u): errs.append(f"Invalid URL: {u}")
        elif u in urls: flash(f"Duplicate URL ignored: {u}", "warn")
        else: urls.append(u)
    files = [x for x in request.files.getlist("file") if x.filename]
    if not urls and not files: errs.append("Add at least one source URL or document.")
    if errs: return q, None, errs
    for u in urls:
        st, txt, note = analysis.fetch_url(u); srcs.append(dict(name=u, kind="URL", status=st, text=txt, note=note))
    for x in files:
        name = secure_filename(x.filename) or "file"
        try: srcs.append(dict(name=name, kind="File", status="Analysed", text=analysis.read_file(name, x.read()), note=""))
        except Exception as e: srcs.append(dict(name=name, kind="File", status="Failed", text="", note=str(e)))
    return q, srcs, []

@app.route("/new", methods=["GET", "POST"])
def new():
    if request.method == "POST":
        q, srcs, errs = collect()
        if errs:
            for e in errs: flash(e, "err")
            return render_template("new.html", title="Research Workplace", q=q), 400
        return redirect(url_for("project", pid=create_project(q, srcs).id))
    return render_template("new.html", title="Research Workplace", q="")

@app.route("/demo", methods=["POST"])
def demo():
    q = "What should I verify before applying for this engineering scholarship?"
    return redirect(url_for("project", pid=create_project(q, [dict(s) for s in analysis.DEMO], True).id))

@app.route("/project/<int:pid>")
def project(pid):
    p = db.get_or_404(Project, pid)
    asp = {}
    for c in p.claims: asp.setdefault(c.aspect, set()).add(c.source_id)
    stats = dict(processed=sum(x.status == "Analysed" for x in p.sources), failed=sum(x.status != "Analysed" for x in p.sources),
                 claims=len(p.claims), relevant=len({c.source_id for c in p.claims}), corroborated=sum(len(v) > 1 for v in asp.values()),
                 single=sum(len(v) == 1 for v in asp.values()))
    return render_template("project.html", p=p, stats=stats, title=p.title, method=analysis.METHOD, aspects=list(analysis.ASPECTS))

@app.route("/project/<int:pid>/delete", methods=["POST"])
def delete(pid):
    db.session.delete(db.get_or_404(Project, pid)); db.session.commit(); flash("Research deleted.", "ok"); return redirect(url_for("history"))

@app.route("/history")
def history(): return render_template("history.html", P=Project.query.order_by(Project.created.desc()).all(), title="Research History")

def filt(M, cols):
    qy = M.query
    for c in cols:
        v = request.args.get(c)
        if v: qy = qy.filter(getattr(M, c) == v)
    return qy

@app.route("/gaps")
def gaps(): return render_template("items.html", kind="gaps", rows=filt(Gap, ["severity", "status"]).order_by(Gap.id).all(), title="Gap Analysis")
@app.route("/conflicts")
def conflicts(): return render_template("items.html", kind="conflicts", rows=filt(Conflict, ["severity"]).all(), title="Conflict Radar")
@app.route("/freshness")
def freshness(): return render_template("items.html", kind="freshness", rows=filt(Source, ["freshness"]).all(), title="Freshness Monitor")
@app.route("/questions")
def questions(): return render_template("items.html", kind="questions", rows=filt(Question, ["priority"]).all(), title="Unanswered Questions")
@app.route("/verify")
def verify(): return render_template("items.html", kind="tasks", rows=filt(Task, ["status", "priority"]).all(), title="Verification Center")
@app.route("/about")
def about(): return render_template("about.html", title="About", method=analysis.METHOD)

@app.route("/update/<kind>/<int:i>", methods=["POST"])
def update(kind, i):
    M = {"task": Task, "gap": Gap}.get(kind)
    if kind == "question":
        q = db.get_or_404(Question, i); q.resolved = request.form.get("v") == "1"
    elif M:
        o = db.get_or_404(M, i); v = request.form.get("v")
        if v not in STATUS: abort(400)
        o.status = v
    else: abort(404)
    db.session.commit(); return redirect(request.referrer or url_for("dashboard"))

@app.route("/project/<int:pid>/report.pdf")
def report(pid):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    p = db.get_or_404(Project, pid); ss = getSampleStyleSheet(); buf = io.BytesIO()
    P = lambda t, s="BodyText": Paragraph(escape(str(t or "")), ss[s])
    def tbl(head, rows, w):
        t = Table([[P(h) for h in head]] + [[P(c) for c in r] for r in rows], colWidths=w, repeatRows=1)
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#c7d2fe")), ("GRID", (0, 0), (-1, -1), .4, colors.grey), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        return t
    S = [P("Digital Dark Spot AI - Research Report", "Title"), P(f"Question: {p.question}"), P(f"Analysed: {p.created:%Y-%m-%d %H:%M} UTC" + ("  |  DEMO SAMPLE DATA" if p.is_demo else "")),
         P(f"Coverage: {p.found} of {p.total} research aspects had supporting statements ({p.coverage}%). This is aspect coverage, not model accuracy."), Spacer(1, 8)]
    sec = lambda n, h, r, w: S.extend([P(n, "Heading2"), tbl(h, r, w) if r else P("None detected.")])
    sec("Sources analysed", ["Source", "Status", "Freshness", "Reason"], [[s.name, s.status, s.freshness, s.fresh_reason] for s in p.sources], [150, 50, 80, 220])
    sec("Extracted claims (quoted evidence)", ["Aspect", "Source", "Evidence"], [[c.aspect, c.source.name, c.text] for c in p.claims], [100, 120, 280])
    sec("Potential information gaps", ["Gap", "Severity", "Why it matters", "Verify"], [[g.title, g.severity, g.why, g.action] for g in p.gaps], [120, 50, 160, 170])
    sec("Potential conflicts", ["Type", "Claim A (source)", "Claim B (source)", "Resolution"], [[c.ctype, f"{c.a_text} [{c.a_src}]", f"{c.b_text} [{c.b_src}]", c.resolution] for c in p.conflicts], [80, 150, 150, 120])
    sec("Unanswered questions", ["Question", "Priority", "Why"], [[q.text, q.priority, q.why] for q in p.questions], [220, 50, 230])
    sec("Verification checklist", ["Task", "Priority", "Status", "Action"], [[t.title, t.priority, t.status, t.action] for t in p.tasks], [150, 50, 60, 240])
    S += [P("Methodology", "Heading2"), P(analysis.METHOD), P("Limitations", "Heading2"),
          P("Findings are potential signals. Keyword matching can miss or misread context. Sources that could not be fetched are marked Unable to Verify. Tamil text may not render in this PDF because only standard Latin fonts are embedded.")]
    def foot(c, d): c.setFont("Helvetica", 8); c.drawRightString(570, 20, f"Page {d.page}")
    SimpleDocTemplate(buf, pagesize=A4, title="Digital Dark Spot AI Report").build(S, onFirstPage=foot, onLaterPages=foot); buf.seek(0)
    return send_file(buf, mimetype="application/pdf", as_attachment=True, download_name=f"dds_report_{pid}.pdf")

@app.route("/sources")
def sources():
    qy = Source.query
    for c in ("status", "kind"):
        if request.args.get(c): qy = qy.filter(getattr(Source, c) == request.args[c])
    rows = [(x, Claim.query.filter_by(source_id=x.id).count()) for x in qy.order_by(Source.id.desc()).all()]
    return render_template("sources.html", rows=rows, title="Source Library")

@app.route("/graph")
def graph():
    pid = request.args.get("pid", type=int)
    P = Project.query.order_by(Project.created.desc()).all()
    return render_template("graph.html", P=P, pid=pid or (P[0].id if P else None), title="Knowledge Map")

@app.route("/graph/data/<int:pid>")
def graph_data(pid):
    p = db.get_or_404(Project, pid); N, E = [], []
    n = lambda i, label, typ, detail: N.append({"data": {"id": i, "label": label[:40], "type": typ, "detail": detail}})
    e = lambda a, b: E.append({"data": {"id": f"{a}>{b}", "source": a, "target": b}})
    n("topic", p.question, "topic", p.question)
    for s in p.sources: n(f"s{s.id}", s.name, "source", f"{s.status} | {s.freshness}: {s.fresh_reason}"); e("topic", f"s{s.id}")
    for c in p.claims: n(f"c{c.id}", c.text, "claim", f"[{c.aspect}] {c.text} (source: {c.source.name})"); e(f"s{c.source_id}", f"c{c.id}")
    byname = {s.name: f"s{s.id}" for s in p.sources}; gid = {}
    for g in p.gaps:
        gid[g.title] = f"g{g.id}"; n(f"g{g.id}", g.title, "gap", f"{g.severity}: {g.why}")
        e(byname.get(g.source_ref, "topic"), f"g{g.id}")
    cid = {}
    for c in p.conflicts:
        n(f"x{c.id}", c.ctype, "conflict", f"A: {c.a_text} | B: {c.b_text}"); e(byname[c.a_src], f"x{c.id}"); e(byname[c.b_src], f"x{c.id}")
        cid[(c.ctype, c.aspect, f"{c.a_src} / {c.b_src}")] = f"x{c.id}"
    for t in p.tasks:
        n(f"t{t.id}", t.title, "task", f"{t.priority} | {t.status}: {t.action}")
        src = gid.get(t.title) or next((v for (ct, a, r), v in cid.items() if t.title == f"Resolve: {ct} ({a})" and r == t.ref), None) or byname.get(t.ref, "topic")
        e(src, f"t{t.id}")
    return {"elements": N + E}

@app.route("/reports")
def reports(): return render_template("reports.html", P=Project.query.order_by(Project.created.desc()).all(), title="Research Reports")

@app.route("/settings", methods=["GET", "POST"])
def settings():
    if request.method == "POST":
        th, lg = request.form.get("theme", ""), request.form.get("lang", "en")
        if th in ("", "dark", "ocean") and lg in ("en", "ta"): session["theme"], session["lang"] = th, lg; flash("Settings saved.", "ok")
        return redirect(url_for("settings"))
    return render_template("settings.html", title="Settings")

if __name__ == "__main__": app.run(debug=False)
