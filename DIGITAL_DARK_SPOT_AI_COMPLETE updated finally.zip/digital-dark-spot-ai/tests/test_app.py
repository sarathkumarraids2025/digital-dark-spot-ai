import os, sys, tempfile, io
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
os.environ["DATABASE_URL"] = "sqlite:///" + os.path.join(tempfile.mkdtemp(), "t.db")
import pytest, analysis
from app import app, db, Project, Task

@pytest.fixture
def c():
    app.config["TESTING"] = True
    with app.test_client() as cl:
        cl.get("/new")
        with cl.session_transaction() as s: cl.t = s["_t"]
        yield cl

def post(c, url, **kw): return c.post(url, data={"_t": c.t, **kw.pop("data", {})}, **kw)

def test_pages(c):
    for u in ["/", "/new", "/history", "/gaps", "/conflicts", "/freshness", "/questions", "/verify", "/about"]:
        assert c.get(u).status_code == 200

def test_csrf_required(c): assert c.post("/demo").status_code == 400

def test_invalid_input(c):
    r = post(c, "/new", data={"question": "short"}); assert r.status_code == 400

def test_demo_workflow_and_persistence(c):
    r = post(c, "/demo"); assert r.status_code == 302
    pid = int(r.location.rsplit("/", 1)[1])
    page = c.get(f"/project/{pid}").get_data(as_text=True)
    assert "Renewal conditions not found" in page and "Date difference" in page
    with app.app_context():
        t = Task.query.filter_by(project_id=pid).first(); tid = t.id
    post(c, f"/update/task/{tid}", data={"v": "Completed"})
    with app.app_context(): assert db.session.get(Task, tid).status == "Completed"
    assert "Completed" in c.get("/verify?status=Completed").get_data(as_text=True)
    pdf = c.get(f"/project/{pid}/report.pdf"); assert pdf.data.startswith(b"%PDF")
    for u in ["/", "/gaps?severity=High", "/conflicts", "/freshness?freshness=Potentially%20Outdated"]: assert c.get(u).status_code == 200
    assert post(c, f"/project/{pid}/delete").status_code == 302

def test_upload_and_bad_file(c):
    d = {"question": "What should I verify before applying?", "file": [(io.BytesIO(b"Eligibility criteria: must be a first year student. Deadline is 1 March 2026 for all."), "a.txt"), (io.BytesIO(b""), "empty.txt")]}
    r = c.post("/new", data={"_t": c.t, **d}, content_type="multipart/form-data"); assert r.status_code == 302
    page = c.get(r.location).get_data(as_text=True); assert "File is empty" in page

def test_duplicate_and_ssrf():
    assert not analysis._safe_host("localhost") and not analysis.valid_url("ftp://x.com") and not analysis.valid_url("notaurl")
    st, _, note = analysis.fetch_url("http://127.0.0.1/"); assert st == "Failed" and "Blocked" in note

def test_engine():
    r = analysis.analyse("q", [dict(s) for s in analysis.DEMO])
    assert r["coverage"] == 75.0 and any(g["title"].startswith("Renewal") for g in r["gaps"])
    types = {c["ctype"] for c in r["conflicts"]}; assert any("Date difference" in t for t in types) and any("Document" in t for t in types)
    assert any(s["freshness"] == "Potentially Outdated" for s in r["sources"])
    assert any("possible different cycle" in c["ctype"] and c["severity"] == "Low" for c in r["conflicts"])
    assert analysis.analyse("q", [dict(name="x", kind="URL", status="Failed", text="", note="n")])["sources"][0]["freshness"] == "Unable to Verify"

def test_all_sidebar_pages(c):
    post(c, "/demo")
    for u in ["/", "/new", "/history", "/sources", "/gaps", "/conflicts", "/freshness", "/questions", "/graph", "/verify", "/reports", "/settings", "/about"]:
        r = c.get(u); assert r.status_code == 200, u
        assert "Knowledge Map" in r.get_data(as_text=True) and 'id="col"' in r.get_data(as_text=True)

def test_graph_data_and_sources(c):
    pid = int(post(c, "/demo").location.rsplit("/", 1)[1])
    els = c.get(f"/graph/data/{pid}").get_json()["elements"]
    types = {e["data"].get("type") for e in els}
    assert {"topic", "source", "claim", "gap", "conflict", "task"} <= types
    ids = {e["data"]["id"] for e in els if "type" in e["data"]}
    assert all(e["data"]["source"] in ids and e["data"]["target"] in ids for e in els if "source" in e["data"])
    assert "DEMO: Student blog post" in c.get("/sources?status=Analysed").get_data(as_text=True)
    assert c.get("/graph/data/99999").status_code == 404

def test_settings_persist_and_tamil(c):
    post(c, "/settings", data={"theme": "ocean", "lang": "ta"})
    page = c.get("/about").get_data(as_text=True)
    assert 'data-theme="ocean"' in page and "டாஷ்போர்டு" in page
    post(c, "/settings", data={"theme": "bogus", "lang": "en"})
    assert 'data-theme="ocean"' in c.get("/about").get_data(as_text=True)
    post(c, "/settings", data={"theme": "", "lang": "en"})

def test_project_overview(c):
    pid = int(post(c, "/demo").location.rsplit("/", 1)[1])
    page = c.get(f"/project/{pid}").get_data(as_text=True)
    assert "claims extracted" in page and "relevant sources" in page
